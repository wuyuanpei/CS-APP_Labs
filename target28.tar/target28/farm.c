/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_224()
{
    return 2999160912U;
}

unsigned addval_201(unsigned x)
{
    return x + 2421690746U;
}

unsigned getval_337()
{
    return 2428996936U;
}

void setval_198(unsigned *p)
{
    *p = 2445773128U;
}

void setval_299(unsigned *p)
{
    *p = 2428995912U;
}

unsigned getval_315()
{
    return 1481149661U;
}

unsigned addval_133(unsigned x)
{
    return x + 3281031240U;
}

unsigned addval_347(unsigned x)
{
    return x + 2428995912U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_490()
{
    return 3281047179U;
}

unsigned addval_422(unsigned x)
{
    return x + 3229143433U;
}

unsigned getval_203()
{
    return 3234120329U;
}

void setval_489(unsigned *p)
{
    *p = 432263577U;
}

unsigned getval_296()
{
    return 3281047177U;
}

void setval_112(unsigned *p)
{
    *p = 3373846921U;
}

unsigned getval_419()
{
    return 3526939049U;
}

void setval_329(unsigned *p)
{
    *p = 3353381192U;
}

void setval_172(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_256(unsigned x)
{
    return x + 3674784397U;
}

void setval_395(unsigned *p)
{
    *p = 3531919017U;
}

unsigned addval_396(unsigned x)
{
    return x + 3531919017U;
}

void setval_434(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_211()
{
    return 3531132553U;
}

unsigned addval_148(unsigned x)
{
    return x + 3227566729U;
}

void setval_467(unsigned *p)
{
    *p = 3285289308U;
}

unsigned addval_381(unsigned x)
{
    return x + 3526938889U;
}

void setval_413(unsigned *p)
{
    *p = 3281047945U;
}

unsigned addval_151(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_457(unsigned x)
{
    return x + 3531133321U;
}

unsigned addval_182(unsigned x)
{
    return x + 3767091300U;
}

void setval_238(unsigned *p)
{
    *p = 2428668371U;
}

void setval_458(unsigned *p)
{
    *p = 3383018121U;
}

unsigned addval_122(unsigned x)
{
    return x + 3268315607U;
}

unsigned getval_157()
{
    return 3286288712U;
}

unsigned getval_460()
{
    return 3286272328U;
}

void setval_356(unsigned *p)
{
    *p = 3281047177U;
}

unsigned getval_233()
{
    return 3682910857U;
}

void setval_137(unsigned *p)
{
    *p = 3223375513U;
}

void setval_293(unsigned *p)
{
    *p = 3525362345U;
}

void setval_216(unsigned *p)
{
    *p = 3286272329U;
}

void setval_423(unsigned *p)
{
    *p = 3527983753U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
